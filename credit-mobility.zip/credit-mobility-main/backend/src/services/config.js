const config = {
  university: process.env.UNIVERSITY,
  blockchain_node: process.env.BLOCKCHAIN_NODE,
  db_source: process.env.DB_SOURCE,
};

module.exports = config;
