#!/bin/bash
cp ./build/contracts/UniversityRegistry.json ../backend/contracts/UniversityRegistry.json
cp ./build/contracts/TransferLog.json ../backend/contracts/TransferLog.json
