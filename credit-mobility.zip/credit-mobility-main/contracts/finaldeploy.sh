#!/bin/bash
PARTNER_A_UNIVERSITY="RWTH" PARTNER_A_DEPARTMENT="Department of Computer Science" PARTNER_A_SERVER="https://localhost:3000" PARTNER_B_PUBKEY="0x7c24D17e8D81C0688CE1E858b151989Be54C45F9" PARTNER_B_UNIVERSITY="NUS" PARTNER_B_DEPARTMENT="School of Computing" PARTNER_B_SERVER="https://localhost:3001" truffle migrate --network goerli
